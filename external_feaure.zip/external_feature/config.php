<?php
session_start();

//Include Google client library 
include_once 'src/Google_Client.php';
include_once 'src/contrib/Google_Oauth2Service.php';

/*
 * Configuration and setup Google API
 */
$clientId = '633879115401-9nrfg3rtq9k6l6fq6d2l10agnj6nqsqm.apps.googleusercontent.com';
$clientSecret = 'bxKfeB30pzAbAdV7gF1u9T0k';
$redirectURL = 'http://localhost/external_feature/';

//Call Google API
$gClient = new Google_Client();
$gClient->setApplicationName('Login to Personal Finance Management');
$gClient->setClientId($clientId);
$gClient->setClientSecret($clientSecret);
$gClient->setRedirectUri($redirectURL);

$google_oauthV2 = new Google_Oauth2Service($gClient);
?>