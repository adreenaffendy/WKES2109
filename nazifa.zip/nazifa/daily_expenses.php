<?php 

  include('server-registration.php');
  include('header.php');
  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }


 ?>
<body>
	<br>
	<br>
	<br>
	<p>Upcoming</p>

</body>


 <?php include 'footer.php'; ?>