<?php 

  include('server-registration.php');
  include('header.php');
  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
  }

  $id = $_GET['id'];
   $db = mysqli_connect('localhost', 'root', '', 'web'); 
   $sql = "SELECT * from goals where goals.id =$id;";
   $result = mysqli_query($db, $sql);
   $row = mysqli_fetch_assoc($result);
 ?>



<body>
	<br><br><br>	

  <div class="header">
  	<h2><?php echo $row['name']; ?></h2>
  </div>
  <form>
	<p>Goal: <?php echo $row['name']; ?></p>
	<p>Monthly Budget: <?php echo $row['monthly_budget']; ?></p>
	<p>Total Budget: <?php echo $row['total_budget']; ?></p>
	<p>Description: <?php echo $row['description']; ?></p>
	<p>Date Created: <?php echo $row['date_created']; ?></p>
  </form>
</body>



 <?php include('footer.php'); ?>